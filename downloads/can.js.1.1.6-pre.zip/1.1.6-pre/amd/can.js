/*!
* CanJS - 1.1.6-pre (2013-05-01)
* http://canjs.us/
* Copyright (c) 2013 Bitovi
* Licensed MIT
*/
define(['can/util/library', 'can/control/route', 'can/model', 'can/view/ejs', 'can/route'], function(can) {
    return can;
});