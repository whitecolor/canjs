/*!
* CanJS - 1.1.4 (2013-02-05)
* http://canjs.us/
* Copyright (c) 2013 Bitovi
* Licensed MIT
*/
define(['can/util/library', 'can/control/route', 'can/model', 'can/view/ejs', 'can/route'], function (can) {
	return can;
});