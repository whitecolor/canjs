/*!
* CanJS - 1.1.5-pre (2013-02-12)
* http://canjs.us/
* Copyright (c) 2013 Bitovi
* Licensed MIT
*/
define(['can/util/jquery'], function (can) {
	return can;
});